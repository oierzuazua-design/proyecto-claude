
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { EditType, VideoEdit } from "../types";

export class VideoGeminiService {
  private static getAI() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  /**
   * Parses a natural language command into structured video editing instructions.
   */
  static async parseCommand(prompt: string, currentTime: number): Promise<Partial<VideoEdit>> {
    const ai = this.getAI();
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User command: "${prompt}". Current video playback time: ${currentTime}s.`,
      config: {
        systemInstruction: `You are an AI Video Editor expert. Extract specific editing tasks from the user command. 
        Supported types: SLOW_MOTION, SUBTITLES, EMOJI, FREEZE_FRAME, COLOR_FILTER, EXTEND_VIDEO.
        If the user doesn't specify times, use the current playback time or reasonable defaults.
        Return ONLY valid JSON.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING, enum: Object.values(EditType) },
            startTime: { type: Type.NUMBER, description: "Start time in seconds" },
            endTime: { type: Type.NUMBER, description: "End time in seconds" },
            content: { type: Type.STRING, description: "Subtitle text, emoji character, or filter name" },
            parameters: { type: Type.OBJECT, description: "Additional data like emoji position or filter intensity" }
          },
          required: ["type"]
        }
      }
    });

    try {
      return JSON.parse(response.text || '{}');
    } catch (e) {
      console.error("Failed to parse AI response", e);
      return { type: EditType.UNKNOWN };
    }
  }

  /**
   * For complex creative transformations or extending video using Veo.
   */
  static async generateVideoExtension(prompt: string, videoBase64: string): Promise<string | null> {
    const ai = this.getAI();
    
    try {
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: prompt,
        image: {
          imageBytes: videoBase64,
          mimeType: 'image/png' // Assuming we send a frame as starting reference
        },
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '16:9'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      if (!downloadLink) return null;

      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      const blob = await response.blob();
      return URL.createObjectURL(blob);
    } catch (error) {
      console.error("Video generation error:", error);
      throw error;
    }
  }
}
