
import React, { useRef, useEffect, useState } from 'react';
import { VideoEdit, EditType } from '../types';

interface VideoPlayerProps {
  url: string;
  edits: VideoEdit[];
  onTimeUpdate: (time: number) => void;
  onDurationChange: (duration: number) => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ url, edits, onTimeUpdate, onDurationChange }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTime = () => {
      let time = video.currentTime;
      
      // Handle SLOW MOTION simulation
      const activeSlowMo = edits.find(e => 
        e.type === EditType.SLOW_MOTION && 
        time >= (e.startTime || 0) && 
        time <= (e.endTime || 0)
      );
      
      if (activeSlowMo) {
        video.playbackRate = 0.5;
      } else {
        video.playbackRate = 1.0;
      }

      setCurrentTime(time);
      onTimeUpdate(time);
    };

    const handleLoadedMetadata = () => {
      onDurationChange(video.duration);
    };

    video.addEventListener('timeupdate', handleTime);
    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    return () => {
      video.removeEventListener('timeupdate', handleTime);
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [edits, onTimeUpdate, onDurationChange]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  // Render Overlay Edits
  const renderEdits = () => {
    return edits.map(edit => {
      const isActive = currentTime >= (edit.startTime || 0) && currentTime <= (edit.endTime || 1000);
      if (!isActive) return null;

      switch (edit.type) {
        case EditType.SUBTITLES:
          return (
            <div key={edit.id} className="absolute bottom-12 left-0 right-0 flex justify-center pointer-events-none">
              <span className="bg-black/70 text-white px-4 py-2 rounded-lg text-lg font-medium animate-pulse">
                {edit.content}
              </span>
            </div>
          );
        case EditType.EMOJI:
          return (
            <div 
              key={edit.id} 
              className="absolute text-6xl pointer-events-none transition-all duration-300"
              style={{ 
                left: `${edit.position?.x || 50}%`, 
                top: `${edit.position?.y || 50}%`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              {edit.content}
            </div>
          );
        case EditType.COLOR_FILTER:
           return (
            <div 
              key={edit.id} 
              className="absolute inset-0 pointer-events-none opacity-40 mix-blend-overlay"
              style={{ backgroundColor: edit.content || 'transparent' }}
            />
          );
        default:
          return null;
      }
    });
  };

  return (
    <div className="relative group w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-neutral-800">
      <video
        ref={videoRef}
        src={url}
        className="w-full h-full object-contain"
        onClick={togglePlay}
      />
      
      {/* Overlay Layer */}
      <div className="absolute inset-0 pointer-events-none">
        {renderEdits()}
      </div>

      {/* Custom Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-center gap-4">
          <button 
            onClick={togglePlay}
            className="text-white hover:text-indigo-400 transition-colors"
          >
            <i className={`fa-solid ${isPlaying ? 'fa-pause' : 'fa-play'} text-xl`}></i>
          </button>
          
          <div className="flex-1 h-1.5 bg-neutral-700 rounded-full relative overflow-hidden">
            <div 
              className="absolute h-full bg-indigo-500 rounded-full" 
              style={{ width: `${(currentTime / (videoRef.current?.duration || 1)) * 100}%` }}
            />
          </div>
          
          <span className="text-xs font-mono">
            {Math.floor(currentTime / 60)}:{(currentTime % 60).toFixed(0).padStart(2, '0')} / 
            {Math.floor((videoRef.current?.duration || 0) / 60)}:{(Math.floor(videoRef.current?.duration || 0) % 60).toString().padStart(2, '0')}
          </span>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
