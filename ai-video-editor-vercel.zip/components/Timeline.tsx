
import React from 'react';
import { VideoEdit, EditType } from '../types';

interface TimelineProps {
  edits: VideoEdit[];
  duration: number;
}

const Timeline: React.FC<TimelineProps> = ({ edits, duration }) => {
  const getLabel = (type: EditType) => {
    switch(type) {
      case EditType.SLOW_MOTION: return 'Slow-Mo';
      case EditType.SUBTITLES: return 'Subs';
      case EditType.EMOJI: return 'Emoji';
      case EditType.FREEZE_FRAME: return 'Freeze';
      case EditType.COLOR_FILTER: return 'Filter';
      default: return 'Edit';
    }
  };

  const getIcon = (type: EditType) => {
    switch(type) {
      case EditType.SLOW_MOTION: return 'fa-gauge-slow';
      case EditType.SUBTITLES: return 'fa-closed-captioning';
      case EditType.EMOJI: return 'fa-face-smile';
      case EditType.FREEZE_FRAME: return 'fa-snowflake';
      case EditType.COLOR_FILTER: return 'fa-palette';
      default: return 'fa-edit';
    }
  };

  return (
    <div className="h-40 bg-neutral-900/50 border-t border-neutral-800 p-4 overflow-hidden flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-500">Edit Timeline</h3>
        <span className="text-[10px] text-neutral-600">{edits.length} Layers Active</span>
      </div>
      
      <div className="flex-1 relative bg-neutral-950/30 rounded-lg overflow-x-auto border border-neutral-800/50">
        <div className="min-w-full h-full p-2 space-y-2">
          {edits.length === 0 ? (
            <div className="h-full flex items-center justify-center text-neutral-700 text-xs italic">
              No edits applied yet. Use the chat to start.
            </div>
          ) : (
            edits.map(edit => {
              const startPct = ((edit.startTime || 0) / duration) * 100;
              const endPct = ((edit.endTime || duration) / duration) * 100;
              const width = Math.max(endPct - startPct, 5); // Minimum width for visibility

              return (
                <div key={edit.id} className="h-6 relative">
                  <div 
                    className="absolute h-full bg-indigo-500/20 border border-indigo-500/40 rounded px-2 flex items-center gap-1.5 overflow-hidden transition-all hover:bg-indigo-500/30 cursor-pointer"
                    style={{ left: `${startPct}%`, width: `${width}%` }}
                  >
                    <i className={`fa-solid ${getIcon(edit.type)} text-[10px] text-indigo-400`}></i>
                    <span className="text-[10px] font-medium whitespace-nowrap text-indigo-300">
                      {getLabel(edit.type)}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

export default Timeline;
