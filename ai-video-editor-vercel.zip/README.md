<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# AI Video Editor Pro

Tu editor de video con IA, ahora desplegado en la web.

## 🚀 Deploy en Vercel

### Pasos rápidos:

1. **Sube este proyecto a Vercel:**
   - Ve a [vercel.com/new](https://vercel.com/new)
   - Arrastra la carpeta completa del proyecto
   - O importa desde GitHub si subiste el código allí

2. **Configura la variable de entorno:**
   - En Vercel, ve a "Settings" → "Environment Variables"
   - Agrega: `GEMINI_API_KEY` con tu API key de Gemini
   - Aplica a todos los entornos (Production, Preview, Development)

3. **Deploy:**
   - Haz clic en "Deploy"
   - Espera 1-2 minutos
   - ¡Listo! Tendrás una URL tipo `tu-app.vercel.app`

## 💻 Run Locally (Opcional)

**Prerequisites:** Node.js

1. Install dependencies: `npm install`
2. Create `.env.local` file with: `GEMINI_API_KEY=tu_api_key_aqui`
3. Run the app: `npm run dev`

---

📱 **Accede desde tu móvil usando la URL de Vercel**
