
import React, { useState, useCallback, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import VideoPlayer from './components/VideoPlayer';
import ChatInterface from './components/ChatInterface';
import Timeline from './components/Timeline';
import { AppState, EditType, VideoEdit, Message } from './types';
import { VideoGeminiService } from './services/geminiService';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    videoFile: null,
    videoUrl: null,
    edits: [],
    messages: [
      { 
        id: '1', 
        role: 'assistant', 
        content: 'Hi! I am your AI Video Editor. Upload a video to start editing with natural language commands like "add slow motion at 5 seconds" or "put a pizza emoji in the corner".', 
        timestamp: Date.now() 
      }
    ],
    isApiKeySelected: false
  });

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  // Check for API key selection on mount (for Veo models)
  useEffect(() => {
    const checkKey = async () => {
      if (typeof window.aistudio?.hasSelectedApiKey === 'function') {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setState(prev => ({ ...prev, isApiKeySelected: hasKey }));
      }
    };
    checkKey();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setState(prev => ({
        ...prev,
        videoFile: file,
        videoUrl: url,
        messages: [
          ...prev.messages,
          { id: Date.now().toString(), role: 'assistant', content: 'Great! Video uploaded. What would you like to do?', timestamp: Date.now() }
        ]
      }));
    }
  };

  const openKeySelector = async () => {
    if (typeof window.aistudio?.openSelectKey === 'function') {
      await window.aistudio.openSelectKey();
      setState(prev => ({ ...prev, isApiKeySelected: true }));
    }
  };

  const handleSendMessage = async (text: string) => {
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: Date.now() };
    const loadingMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: '...', timestamp: Date.now(), isProcessing: true };
    
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMsg, loadingMsg]
    }));

    try {
      const parsedEdit = await VideoGeminiService.parseCommand(text, currentTime);
      
      if (parsedEdit.type === EditType.UNKNOWN) {
        setState(prev => ({
          ...prev,
          messages: [
            ...prev.messages.filter(m => !m.isProcessing),
            { id: Date.now().toString(), role: 'assistant', content: "I'm not sure how to do that yet. Try 'slow motion', 'subtitles', or 'add an emoji'.", timestamp: Date.now() }
          ]
        }));
        return;
      }

      const newEdit: VideoEdit = {
        id: Math.random().toString(36).substr(2, 9),
        type: parsedEdit.type || EditType.UNKNOWN,
        startTime: parsedEdit.startTime ?? currentTime,
        endTime: parsedEdit.endTime ?? (currentTime + 3),
        content: parsedEdit.content,
        position: parsedEdit.position,
        parameters: parsedEdit.parameters,
        timestamp: Date.now()
      };

      setState(prev => ({
        ...prev,
        edits: [...prev.edits, newEdit],
        messages: [
          ...prev.messages.filter(m => !m.isProcessing),
          { id: Date.now().toString(), role: 'assistant', content: `Applied ${newEdit.type.toLowerCase().replace('_', ' ')}! Check the timeline.`, timestamp: Date.now() }
        ]
      }));

    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setState(prev => ({ ...prev, isApiKeySelected: false }));
      }
      setState(prev => ({
        ...prev,
        messages: [
          ...prev.messages.filter(m => !m.isProcessing),
          { id: Date.now().toString(), role: 'assistant', content: "Oops, I hit a snag while processing that. Please try again.", timestamp: Date.now() }
        ]
      }));
    }
  };

  if (!state.isApiKeySelected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center space-y-6">
        <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-indigo-500/20 shadow-xl">
          <i className="fa-solid fa-clapperboard text-4xl text-white"></i>
        </div>
        <div>
          <h1 className="text-4xl font-black mb-2 tracking-tight">AI Video Editor Pro</h1>
          <p className="text-neutral-400 max-w-md mx-auto">
            Before we start, you need to select a billing project for Gemini API access.
            This enables professional-grade AI video generation and editing.
          </p>
        </div>
        <div className="bg-neutral-900/50 p-4 rounded-xl border border-neutral-800 text-sm">
          <p className="text-neutral-500 mb-2">Learn more about <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-indigo-400 hover:underline">Gemini Billing</a></p>
          <button 
            onClick={openKeySelector}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-8 rounded-xl transition-all shadow-lg shadow-indigo-600/20"
          >
            Select API Key to Launch
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar - Video Info & Controls */}
      <div className="w-16 flex flex-col items-center py-6 bg-neutral-950 border-r border-neutral-900 space-y-8">
        <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center cursor-pointer">
          <i className="fa-solid fa-play text-white"></i>
        </div>
        <div className="flex flex-col gap-6 text-neutral-500">
          <i className="fa-solid fa-scissors hover:text-indigo-400 cursor-pointer"></i>
          <i className="fa-solid fa-wand-magic-sparkles hover:text-indigo-400 cursor-pointer"></i>
          <i className="fa-solid fa-layer-group hover:text-indigo-400 cursor-pointer"></i>
          <i className="fa-solid fa-gear hover:text-indigo-400 cursor-pointer"></i>
        </div>
        <div className="flex-1"></div>
        <button 
          onClick={() => setState(prev => ({ ...prev, isApiKeySelected: false }))}
          className="text-neutral-600 hover:text-red-400"
        >
          <i className="fa-solid fa-sign-out"></i>
        </button>
      </div>

      <div className="flex-1 flex flex-col">
        {/* Main Content Area */}
        <div className="flex-1 flex overflow-hidden">
          {/* Editor Space */}
          <div className="flex-1 flex flex-col p-6 overflow-hidden">
            <header className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-xl font-bold tracking-tight">
                  {state.videoFile ? state.videoFile.name : 'Untitled Project'}
                </h2>
                <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest mt-0.5">
                  AI-Assisted Workspace
                </p>
              </div>
              <div className="flex gap-3">
                <label className="bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 px-4 py-2 rounded-lg text-sm flex items-center gap-2 cursor-pointer transition-colors">
                  <i className="fa-solid fa-upload text-neutral-400"></i>
                  Upload Video
                  <input type="file" accept="video/*" className="hidden" onChange={handleFileUpload} />
                </label>
                <button className="bg-indigo-600 hover:bg-indigo-500 px-6 py-2 rounded-lg text-sm font-bold shadow-lg shadow-indigo-600/10 transition-all">
                  Export
                </button>
              </div>
            </header>

            <div className="flex-1 flex items-center justify-center relative overflow-hidden bg-neutral-900/30 rounded-3xl border border-neutral-900/50">
              {state.videoUrl ? (
                <div className="w-full max-w-4xl p-4">
                  <VideoPlayer 
                    url={state.videoUrl} 
                    edits={state.edits}
                    onTimeUpdate={setCurrentTime}
                    onDurationChange={setDuration}
                  />
                </div>
              ) : (
                <div className="text-center p-12">
                  <div className="w-24 h-24 bg-neutral-900 rounded-full flex items-center justify-center mx-auto mb-6 text-neutral-800 border-4 border-dashed border-neutral-800">
                    <i className="fa-solid fa-film text-3xl"></i>
                  </div>
                  <h3 className="text-lg font-bold text-neutral-400">Ready for magic?</h3>
                  <p className="text-neutral-600 text-sm max-w-xs mx-auto mt-2">
                    Upload your first video clip to start editing with our advanced AI tools.
                  </p>
                  <label className="mt-8 inline-block bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 px-10 rounded-xl cursor-pointer transition-all">
                    Pick a Video
                    <input type="file" accept="video/*" className="hidden" onChange={handleFileUpload} />
                  </label>
                </div>
              )}
            </div>
          </div>

          {/* Chat Panel */}
          <ChatInterface 
            messages={state.messages} 
            onSendMessage={handleSendMessage} 
          />
        </div>

        {/* Bottom Timeline */}
        <Timeline edits={state.edits} duration={duration} />
      </div>
    </div>
  );
};

export default App;
