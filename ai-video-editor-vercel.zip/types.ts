
export enum EditType {
  SLOW_MOTION = 'SLOW_MOTION',
  SUBTITLES = 'SUBTITLES',
  EMOJI = 'EMOJI',
  FREEZE_FRAME = 'FREEZE_FRAME',
  COLOR_FILTER = 'COLOR_FILTER',
  EXTEND_VIDEO = 'EXTEND_VIDEO',
  UNKNOWN = 'UNKNOWN'
}

export interface VideoEdit {
  id: string;
  type: EditType;
  startTime?: number;
  endTime?: number;
  content?: string;
  position?: { x: number; y: number };
  parameters?: Record<string, any>;
  timestamp: number;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  isProcessing?: boolean;
}

export interface AppState {
  videoFile: File | null;
  videoUrl: string | null;
  edits: VideoEdit[];
  messages: Message[];
  isApiKeySelected: boolean;
}
